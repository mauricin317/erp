--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.6
-- Dumped by pg_dump version 14.6

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE erp;
--
-- Name: erp; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE erp WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'Spanish_Bolivia.1252';


ALTER DATABASE erp OWNER TO postgres;

\connect erp

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: erp; Type: DATABASE PROPERTIES; Schema: -; Owner: postgres
--

ALTER DATABASE erp SET "TimeZone" TO 'America/La_Paz';


\connect erp

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: articulos_bajo_stock_chart(integer, integer, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.articulos_bajo_stock_chart(id_empresa integer, id_categoria integer, max_cantidad integer) RETURNS TABLE(idarticulo integer, nombre character varying, cantidad integer)
    LANGUAGE plpgsql
    AS $$
BEGIN
	return QUERY
		WITH RECURSIVE cat_hijas AS (
		SELECT c.idcategoria, c.idcategoriapadre, c.nombre
		FROM categoria c
		WHERE c.idcategoria = id_categoria ANd idempresa=id_empresa
		UNION
			SELECT c.idcategoria, c.idcategoriapadre, c.nombre
			FROM categoria c INNER JOIN cat_hijas ch ON ch.idcategoria = c.idcategoriapadre
		) SELECT distinct(a.idarticulo), a.nombre, a.cantidad FROM cat_hijas ch
		left join articulocategoria ac on ch.idcategoria=ac.idcategoria
		left join articulo a on ac.idarticulo=a.idarticulo
		where a.idarticulo is not null and a.cantidad<=max_cantidad
		order by a.cantidad;
END;
$$;


ALTER FUNCTION public.articulos_bajo_stock_chart(id_empresa integer, id_categoria integer, max_cantidad integer) OWNER TO postgres;

--
-- Name: detalle_anular_trigger(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.detalle_anular_trigger() RETURNS trigger
    LANGUAGE plpgsql
    AS $_$
DECLARE
	cantidad_a integer;
	stock_l integer;
BEGIN
SELECT cantidad into cantidad_a from articulo where idarticulo=NEW.idarticulo;
SELECT stock into stock_l from lote where idarticulo=NEW.idarticulo AND nrolote=NEW.nrolote;
IF NEW.estado = -1 THEN
EXECUTE 'UPDATE articulo set cantidad=' || (cantidad_a+NEW.cantidad) || ' WHERE idarticulo=$1.idarticulo' USING NEW;
EXECUTE 'UPDATE lote set stock=' || (stock_l+NEW.cantidad) || ',estado=1 WHERE idarticulo=$1.idarticulo AND nrolote=$1.nrolote' USING NEW;
END IF;
RETURN NULL;
END;
$_$;


ALTER FUNCTION public.detalle_anular_trigger() OWNER TO postgres;

--
-- Name: detalle_insert_trigger(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.detalle_insert_trigger() RETURNS trigger
    LANGUAGE plpgsql
    AS $_$
Declare  
 cantidad_a integer;
 stock_l integer;
BEGIN
select cantidad into cantidad_a from articulo where idarticulo=NEW.idarticulo;
select stock into stock_l from lote where idarticulo=NEW.idarticulo AND nrolote=NEW.nrolote; 
EXECUTE 'UPDATE articulo set cantidad='|| (cantidad_a-NEW.cantidad) || ' where idarticulo=$1.idarticulo' USING NEW;
	IF (stock_l-NEW.cantidad) = 0 THEN 
		EXECUTE 'UPDATE lote set stock='|| (stock_l-NEW.cantidad) || ', estado=0 where idarticulo=$1.idarticulo and nrolote=$1.nrolote' USING NEW;
  	ELSE
     	EXECUTE 'UPDATE lote set stock='|| (stock_l-NEW.cantidad) || ' where idarticulo=$1.idarticulo and nrolote=$1.nrolote' USING NEW;
	END IF;

RETURN NULL;
END;
$_$;


ALTER FUNCTION public.detalle_insert_trigger() OWNER TO postgres;

--
-- Name: generar_cuentas_principales(integer, integer, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.generar_cuentas_principales(id_empresa integer, id_usuario integer, niveles_empresa integer) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
	a_count int;
	b_count int;
	c_count int;
	id_cuenta int;
BEGIN
    INSERT INTO public.cuenta(codigo,nombre,nivel,tipocuenta,idusuario,idempresa,idcuentapadre)
	VALUES(CONCAT('1',REPEAT('.0',niveles_empresa-1)), 'Activo', 1, 0,id_usuario,id_empresa,NULL),
	(CONCAT('2',REPEAT('.0',niveles_empresa-1)), 'Pasivo', 1, 0,id_usuario,id_empresa,NULL),
	(CONCAT('3',REPEAT('.0',niveles_empresa-1)), 'Patrimonio', 1, 0,id_usuario,id_empresa,NULL),
	(CONCAT('4',REPEAT('.0',niveles_empresa-1)), 'Ingresos', 1, 0,id_usuario,id_empresa,NULL);
	GET DIAGNOSTICS a_count = ROW_COUNT;
	INSERT INTO public.cuenta(codigo,nombre,nivel,tipocuenta,idusuario,idempresa,idcuentapadre)
	VALUES(CONCAT('5',REPEAT('.0',niveles_empresa-1)), 'Egresos', 1, 0,id_usuario,id_empresa,NULL)
	RETURNING idcuenta INTO id_cuenta;
	GET DIAGNOSTICS b_count = ROW_COUNT;
	INSERT INTO public.cuenta(codigo,nombre,nivel,tipocuenta,idusuario,idempresa,idcuentapadre)
	VALUES(CONCAT('5.1',REPEAT('.0',niveles_empresa-2)), 'Costos', 2, 0,id_usuario,id_empresa,id_cuenta),
	(CONCAT('5.2',REPEAT('.0',niveles_empresa-2)), 'Gastos', 2, 0,id_usuario,id_empresa,id_cuenta);
	GET DIAGNOSTICS c_count = ROW_COUNT;
	return a_count+b_count+c_count as total;
END;
$$;


ALTER FUNCTION public.generar_cuentas_principales(id_empresa integer, id_usuario integer, niveles_empresa integer) OWNER TO postgres;

--
-- Name: lote_anular_trigger(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.lote_anular_trigger() RETURNS trigger
    LANGUAGE plpgsql
    AS $_$
DECLARE
	cantidad_a integer;
BEGIN
SELECT cantidad into cantidad_a from articulo where idarticulo=NEW.idarticulo;
IF NEW.estado = -1 THEN
EXECUTE 'UPDATE articulo set cantidad=' || (cantidad_a-NEW.cantidad) || ' WHERE idarticulo=$1.idarticulo' USING NEW;
END IF;
RETURN NULL;
END;
$_$;


ALTER FUNCTION public.lote_anular_trigger() OWNER TO postgres;

--
-- Name: lote_insert_trigger(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.lote_insert_trigger() RETURNS trigger
    LANGUAGE plpgsql
    AS $_$
Declare  
 nrolote integer;
 cantidad_a integer;
BEGIN
select count(*) into nrolote from lote where idarticulo=NEW.idarticulo; 
select cantidad into cantidad_a from articulo where idarticulo=NEW.idarticulo; 
EXECUTE 'UPDATE lote set nrolote='|| nrolote || ' where idarticulo=$1.idarticulo and idnota=$1.idnota' USING NEW;
EXECUTE 'UPDATE articulo set cantidad='|| (cantidad_a+NEW.cantidad) || ' where idarticulo=$1.idarticulo' USING NEW;
RETURN NULL;
END;
$_$;


ALTER FUNCTION public.lote_insert_trigger() OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: articulo; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.articulo (
    idarticulo integer NOT NULL,
    nombre character varying(50),
    descripcion character varying(100),
    cantidad integer,
    precioventa numeric(10,2),
    idempresa integer,
    idusuario integer
);


ALTER TABLE public.articulo OWNER TO postgres;

--
-- Name: articulo_idarticulo_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.articulo_idarticulo_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.articulo_idarticulo_seq OWNER TO postgres;

--
-- Name: articulo_idarticulo_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.articulo_idarticulo_seq OWNED BY public.articulo.idarticulo;


--
-- Name: articulocategoria; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.articulocategoria (
    idarticulo integer NOT NULL,
    idcategoria integer NOT NULL
);


ALTER TABLE public.articulocategoria OWNER TO postgres;

--
-- Name: categoria; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.categoria (
    idcategoria integer NOT NULL,
    nombre character varying(50),
    descripcion character varying(100),
    idempresa integer,
    idusuario integer,
    idcategoriapadre integer
);


ALTER TABLE public.categoria OWNER TO postgres;

--
-- Name: categoria_idcategoria_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.categoria_idcategoria_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.categoria_idcategoria_seq OWNER TO postgres;

--
-- Name: categoria_idcategoria_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.categoria_idcategoria_seq OWNED BY public.categoria.idcategoria;


--
-- Name: comprobante; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.comprobante (
    idcomprobante integer NOT NULL,
    serie integer,
    glosa character varying(100),
    fecha date,
    tc numeric(10,2),
    estado smallint DEFAULT 2,
    tipocomprobante smallint,
    idusuario integer,
    idmoneda integer,
    idempresa integer
);


ALTER TABLE public.comprobante OWNER TO postgres;

--
-- Name: comprobante_idcomprobante_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.comprobante_idcomprobante_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.comprobante_idcomprobante_seq OWNER TO postgres;

--
-- Name: comprobante_idcomprobante_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.comprobante_idcomprobante_seq OWNED BY public.comprobante.idcomprobante;


--
-- Name: cuenta; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cuenta (
    idcuenta integer NOT NULL,
    codigo character varying(30),
    nombre character varying(50),
    nivel smallint,
    tipocuenta smallint,
    idusuario integer,
    idempresa integer,
    idcuentapadre integer
);


ALTER TABLE public.cuenta OWNER TO postgres;

--
-- Name: cuenta_idcuenta_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.cuenta_idcuenta_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.cuenta_idcuenta_seq OWNER TO postgres;

--
-- Name: cuenta_idcuenta_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.cuenta_idcuenta_seq OWNED BY public.cuenta.idcuenta;


--
-- Name: detalle; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.detalle (
    idarticulo integer NOT NULL,
    nrolote integer NOT NULL,
    idnota integer NOT NULL,
    cantidad integer,
    precioventa numeric(10,2),
    estado smallint DEFAULT 1
);


ALTER TABLE public.detalle OWNER TO postgres;

--
-- Name: detallecomprobante; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.detallecomprobante (
    iddetallecomprobante integer NOT NULL,
    numero integer,
    glosa character varying(100),
    montodebe numeric(10,2),
    montohaber numeric(10,2),
    montodebealt numeric(10,2),
    montohaberalt numeric(10,2),
    idusuario integer,
    idcomprobante integer,
    idcuenta integer
);


ALTER TABLE public.detallecomprobante OWNER TO postgres;

--
-- Name: detallecomprobante_iddetallecomprobante_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.detallecomprobante_iddetallecomprobante_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.detallecomprobante_iddetallecomprobante_seq OWNER TO postgres;

--
-- Name: detallecomprobante_iddetallecomprobante_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.detallecomprobante_iddetallecomprobante_seq OWNED BY public.detallecomprobante.iddetallecomprobante;


--
-- Name: empresa; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.empresa (
    idempresa integer NOT NULL,
    nombre character varying(100),
    nit character varying(10),
    sigla character varying(15),
    telefono character varying(20),
    correo character varying(50),
    direccion text,
    niveles smallint DEFAULT 3,
    estado smallint DEFAULT 1,
    idusuario integer
);


ALTER TABLE public.empresa OWNER TO postgres;

--
-- Name: empresa_idempresa_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.empresa_idempresa_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.empresa_idempresa_seq OWNER TO postgres;

--
-- Name: empresa_idempresa_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.empresa_idempresa_seq OWNED BY public.empresa.idempresa;


--
-- Name: empresamoneda; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.empresamoneda (
    idempresamoneda integer NOT NULL,
    cambio numeric(10,2) DEFAULT NULL::numeric,
    activo smallint DEFAULT 1,
    fecharegistro timestamp without time zone,
    idempresa integer,
    idmonedaprincipal integer,
    idmonedaalternativa integer,
    idusuario integer
);


ALTER TABLE public.empresamoneda OWNER TO postgres;

--
-- Name: empresamoneda_idempresamoneda_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.empresamoneda_idempresamoneda_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.empresamoneda_idempresamoneda_seq OWNER TO postgres;

--
-- Name: empresamoneda_idempresamoneda_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.empresamoneda_idempresamoneda_seq OWNED BY public.empresamoneda.idempresamoneda;


--
-- Name: gestion; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.gestion (
    idgestion integer NOT NULL,
    nombre character varying(50),
    fechainicio date,
    fechafin date,
    estado smallint DEFAULT 1,
    idusuario integer,
    idempresa integer
);


ALTER TABLE public.gestion OWNER TO postgres;

--
-- Name: gestion_idgestion_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.gestion_idgestion_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.gestion_idgestion_seq OWNER TO postgres;

--
-- Name: gestion_idgestion_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.gestion_idgestion_seq OWNED BY public.gestion.idgestion;


--
-- Name: integracion; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.integracion (
    idempresa integer NOT NULL,
    caja integer,
    creditofiscal integer,
    debitofiscal integer,
    compras integer,
    ventas integer,
    it integer,
    itxpagar integer,
    estado smallint DEFAULT 0
);


ALTER TABLE public.integracion OWNER TO postgres;

--
-- Name: lote; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.lote (
    idarticulo integer NOT NULL,
    nrolote integer NOT NULL,
    fechaingreso date,
    fechavencimiento date,
    cantidad integer,
    preciocompra numeric(10,2),
    stock integer,
    idnota integer,
    estado smallint
);


ALTER TABLE public.lote OWNER TO postgres;

--
-- Name: moneda; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.moneda (
    idmoneda integer NOT NULL,
    nombre character varying(30),
    descripcion character varying(50),
    abreviatura character varying(5),
    idusuario integer
);


ALTER TABLE public.moneda OWNER TO postgres;

--
-- Name: moneda_idmoneda_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.moneda_idmoneda_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.moneda_idmoneda_seq OWNER TO postgres;

--
-- Name: moneda_idmoneda_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.moneda_idmoneda_seq OWNED BY public.moneda.idmoneda;


--
-- Name: nota; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.nota (
    idnota integer NOT NULL,
    nronota integer,
    fecha date,
    descripcion character varying(100),
    total numeric(10,2),
    tipo smallint,
    idempresa integer,
    idusuario integer,
    idcomprobante integer,
    estado smallint
);


ALTER TABLE public.nota OWNER TO postgres;

--
-- Name: nota_idnota_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.nota_idnota_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.nota_idnota_seq OWNER TO postgres;

--
-- Name: nota_idnota_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.nota_idnota_seq OWNED BY public.nota.idnota;


--
-- Name: periodo; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.periodo (
    idperiodo integer NOT NULL,
    nombre character varying(50),
    fechainicio date,
    fechafin date,
    estado smallint DEFAULT 1,
    idusuario integer,
    idgestion integer
);


ALTER TABLE public.periodo OWNER TO postgres;

--
-- Name: periodo_idperiodo_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.periodo_idperiodo_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.periodo_idperiodo_seq OWNER TO postgres;

--
-- Name: periodo_idperiodo_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.periodo_idperiodo_seq OWNED BY public.periodo.idperiodo;


--
-- Name: usuario; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.usuario (
    idusuario integer NOT NULL,
    nombre character varying(50) NOT NULL,
    usuario character varying(90) NOT NULL,
    pass character varying(100) NOT NULL,
    tipo smallint DEFAULT 1
);


ALTER TABLE public.usuario OWNER TO postgres;

--
-- Name: usuario_idusuario_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.usuario_idusuario_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.usuario_idusuario_seq OWNER TO postgres;

--
-- Name: usuario_idusuario_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.usuario_idusuario_seq OWNED BY public.usuario.idusuario;


--
-- Name: articulo idarticulo; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.articulo ALTER COLUMN idarticulo SET DEFAULT nextval('public.articulo_idarticulo_seq'::regclass);


--
-- Name: categoria idcategoria; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categoria ALTER COLUMN idcategoria SET DEFAULT nextval('public.categoria_idcategoria_seq'::regclass);


--
-- Name: comprobante idcomprobante; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.comprobante ALTER COLUMN idcomprobante SET DEFAULT nextval('public.comprobante_idcomprobante_seq'::regclass);


--
-- Name: cuenta idcuenta; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cuenta ALTER COLUMN idcuenta SET DEFAULT nextval('public.cuenta_idcuenta_seq'::regclass);


--
-- Name: detallecomprobante iddetallecomprobante; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.detallecomprobante ALTER COLUMN iddetallecomprobante SET DEFAULT nextval('public.detallecomprobante_iddetallecomprobante_seq'::regclass);


--
-- Name: empresa idempresa; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.empresa ALTER COLUMN idempresa SET DEFAULT nextval('public.empresa_idempresa_seq'::regclass);


--
-- Name: empresamoneda idempresamoneda; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.empresamoneda ALTER COLUMN idempresamoneda SET DEFAULT nextval('public.empresamoneda_idempresamoneda_seq'::regclass);


--
-- Name: gestion idgestion; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.gestion ALTER COLUMN idgestion SET DEFAULT nextval('public.gestion_idgestion_seq'::regclass);


--
-- Name: moneda idmoneda; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.moneda ALTER COLUMN idmoneda SET DEFAULT nextval('public.moneda_idmoneda_seq'::regclass);


--
-- Name: nota idnota; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.nota ALTER COLUMN idnota SET DEFAULT nextval('public.nota_idnota_seq'::regclass);


--
-- Name: periodo idperiodo; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.periodo ALTER COLUMN idperiodo SET DEFAULT nextval('public.periodo_idperiodo_seq'::regclass);


--
-- Name: usuario idusuario; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usuario ALTER COLUMN idusuario SET DEFAULT nextval('public.usuario_idusuario_seq'::regclass);


--
-- Data for Name: articulo; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.articulo (idarticulo, nombre, descripcion, cantidad, precioventa, idempresa, idusuario) FROM stdin;
\.
COPY public.articulo (idarticulo, nombre, descripcion, cantidad, precioventa, idempresa, idusuario) FROM '$$PATH$$/3493.dat';

--
-- Data for Name: articulocategoria; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.articulocategoria (idarticulo, idcategoria) FROM stdin;
\.
COPY public.articulocategoria (idarticulo, idcategoria) FROM '$$PATH$$/3496.dat';

--
-- Data for Name: categoria; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.categoria (idcategoria, nombre, descripcion, idempresa, idusuario, idcategoriapadre) FROM stdin;
\.
COPY public.categoria (idcategoria, nombre, descripcion, idempresa, idusuario, idcategoriapadre) FROM '$$PATH$$/3495.dat';

--
-- Data for Name: comprobante; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.comprobante (idcomprobante, serie, glosa, fecha, tc, estado, tipocomprobante, idusuario, idmoneda, idempresa) FROM stdin;
\.
COPY public.comprobante (idcomprobante, serie, glosa, fecha, tc, estado, tipocomprobante, idusuario, idmoneda, idempresa) FROM '$$PATH$$/3489.dat';

--
-- Data for Name: cuenta; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.cuenta (idcuenta, codigo, nombre, nivel, tipocuenta, idusuario, idempresa, idcuentapadre) FROM stdin;
\.
COPY public.cuenta (idcuenta, codigo, nombre, nivel, tipocuenta, idusuario, idempresa, idcuentapadre) FROM '$$PATH$$/3483.dat';

--
-- Data for Name: detalle; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.detalle (idarticulo, nrolote, idnota, cantidad, precioventa, estado) FROM stdin;
\.
COPY public.detalle (idarticulo, nrolote, idnota, cantidad, precioventa, estado) FROM '$$PATH$$/3500.dat';

--
-- Data for Name: detallecomprobante; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.detallecomprobante (iddetallecomprobante, numero, glosa, montodebe, montohaber, montodebealt, montohaberalt, idusuario, idcomprobante, idcuenta) FROM stdin;
\.
COPY public.detallecomprobante (iddetallecomprobante, numero, glosa, montodebe, montohaber, montodebealt, montohaberalt, idusuario, idcomprobante, idcuenta) FROM '$$PATH$$/3491.dat';

--
-- Data for Name: empresa; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.empresa (idempresa, nombre, nit, sigla, telefono, correo, direccion, niveles, estado, idusuario) FROM stdin;
\.
COPY public.empresa (idempresa, nombre, nit, sigla, telefono, correo, direccion, niveles, estado, idusuario) FROM '$$PATH$$/3477.dat';

--
-- Data for Name: empresamoneda; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.empresamoneda (idempresamoneda, cambio, activo, fecharegistro, idempresa, idmonedaprincipal, idmonedaalternativa, idusuario) FROM stdin;
\.
COPY public.empresamoneda (idempresamoneda, cambio, activo, fecharegistro, idempresa, idmonedaprincipal, idmonedaalternativa, idusuario) FROM '$$PATH$$/3487.dat';

--
-- Data for Name: gestion; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.gestion (idgestion, nombre, fechainicio, fechafin, estado, idusuario, idempresa) FROM stdin;
\.
COPY public.gestion (idgestion, nombre, fechainicio, fechafin, estado, idusuario, idempresa) FROM '$$PATH$$/3479.dat';

--
-- Data for Name: integracion; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.integracion (idempresa, caja, creditofiscal, debitofiscal, compras, ventas, it, itxpagar, estado) FROM stdin;
\.
COPY public.integracion (idempresa, caja, creditofiscal, debitofiscal, compras, ventas, it, itxpagar, estado) FROM '$$PATH$$/3501.dat';

--
-- Data for Name: lote; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.lote (idarticulo, nrolote, fechaingreso, fechavencimiento, cantidad, preciocompra, stock, idnota, estado) FROM stdin;
\.
COPY public.lote (idarticulo, nrolote, fechaingreso, fechavencimiento, cantidad, preciocompra, stock, idnota, estado) FROM '$$PATH$$/3499.dat';

--
-- Data for Name: moneda; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.moneda (idmoneda, nombre, descripcion, abreviatura, idusuario) FROM stdin;
\.
COPY public.moneda (idmoneda, nombre, descripcion, abreviatura, idusuario) FROM '$$PATH$$/3485.dat';

--
-- Data for Name: nota; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.nota (idnota, nronota, fecha, descripcion, total, tipo, idempresa, idusuario, idcomprobante, estado) FROM stdin;
\.
COPY public.nota (idnota, nronota, fecha, descripcion, total, tipo, idempresa, idusuario, idcomprobante, estado) FROM '$$PATH$$/3498.dat';

--
-- Data for Name: periodo; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.periodo (idperiodo, nombre, fechainicio, fechafin, estado, idusuario, idgestion) FROM stdin;
\.
COPY public.periodo (idperiodo, nombre, fechainicio, fechafin, estado, idusuario, idgestion) FROM '$$PATH$$/3481.dat';

--
-- Data for Name: usuario; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.usuario (idusuario, nombre, usuario, pass, tipo) FROM stdin;
\.
COPY public.usuario (idusuario, nombre, usuario, pass, tipo) FROM '$$PATH$$/3475.dat';

--
-- Name: articulo_idarticulo_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.articulo_idarticulo_seq', 16, true);


--
-- Name: categoria_idcategoria_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.categoria_idcategoria_seq', 33, true);


--
-- Name: comprobante_idcomprobante_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.comprobante_idcomprobante_seq', 84, true);


--
-- Name: cuenta_idcuenta_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.cuenta_idcuenta_seq', 347, true);


--
-- Name: detallecomprobante_iddetallecomprobante_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.detallecomprobante_iddetallecomprobante_seq', 281, true);


--
-- Name: empresa_idempresa_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.empresa_idempresa_seq', 29, true);


--
-- Name: empresamoneda_idempresamoneda_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.empresamoneda_idempresamoneda_seq', 45, true);


--
-- Name: gestion_idgestion_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.gestion_idgestion_seq', 32, true);


--
-- Name: moneda_idmoneda_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.moneda_idmoneda_seq', 5, true);


--
-- Name: nota_idnota_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.nota_idnota_seq', 35, true);


--
-- Name: periodo_idperiodo_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.periodo_idperiodo_seq', 81, true);


--
-- Name: usuario_idusuario_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.usuario_idusuario_seq', 1, true);


--
-- Name: articulo articulo_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.articulo
    ADD CONSTRAINT articulo_pkey PRIMARY KEY (idarticulo);


--
-- Name: articulocategoria articulocategoria_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.articulocategoria
    ADD CONSTRAINT articulocategoria_pkey PRIMARY KEY (idarticulo, idcategoria);


--
-- Name: categoria categoria_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categoria
    ADD CONSTRAINT categoria_pkey PRIMARY KEY (idcategoria);


--
-- Name: comprobante comprobante_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.comprobante
    ADD CONSTRAINT comprobante_pkey PRIMARY KEY (idcomprobante);


--
-- Name: cuenta cuenta_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cuenta
    ADD CONSTRAINT cuenta_pkey PRIMARY KEY (idcuenta);


--
-- Name: detalle detalle_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.detalle
    ADD CONSTRAINT detalle_pkey PRIMARY KEY (idarticulo, nrolote, idnota);


--
-- Name: detallecomprobante detallecomprobante_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.detallecomprobante
    ADD CONSTRAINT detallecomprobante_pkey PRIMARY KEY (iddetallecomprobante);


--
-- Name: empresa empresa_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.empresa
    ADD CONSTRAINT empresa_pkey PRIMARY KEY (idempresa);


--
-- Name: empresamoneda empresamoneda_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.empresamoneda
    ADD CONSTRAINT empresamoneda_pkey PRIMARY KEY (idempresamoneda);


--
-- Name: gestion gestion_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.gestion
    ADD CONSTRAINT gestion_pkey PRIMARY KEY (idgestion);


--
-- Name: integracion integracion_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.integracion
    ADD CONSTRAINT integracion_pkey PRIMARY KEY (idempresa);


--
-- Name: lote lote_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lote
    ADD CONSTRAINT lote_pkey PRIMARY KEY (idarticulo, nrolote);


--
-- Name: moneda moneda_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.moneda
    ADD CONSTRAINT moneda_pkey PRIMARY KEY (idmoneda);


--
-- Name: nota nota_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.nota
    ADD CONSTRAINT nota_pkey PRIMARY KEY (idnota);


--
-- Name: periodo periodo_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.periodo
    ADD CONSTRAINT periodo_pkey PRIMARY KEY (idperiodo);


--
-- Name: usuario usuario_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usuario
    ADD CONSTRAINT usuario_pkey PRIMARY KEY (idusuario);


--
-- Name: fki_cuenta_idempresa_fkey; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fki_cuenta_idempresa_fkey ON public.cuenta USING btree (idempresa);


--
-- Name: fki_empresamoneda_idempresa_fkey; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fki_empresamoneda_idempresa_fkey ON public.empresamoneda USING btree (idempresa);


--
-- Name: detalle trigg_detalle_anular; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigg_detalle_anular AFTER UPDATE ON public.detalle FOR EACH ROW EXECUTE FUNCTION public.detalle_anular_trigger();


--
-- Name: detalle trigg_detalle_insert; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigg_detalle_insert AFTER INSERT ON public.detalle FOR EACH ROW EXECUTE FUNCTION public.detalle_insert_trigger();


--
-- Name: lote trigg_lote_anular; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigg_lote_anular AFTER UPDATE ON public.lote FOR EACH ROW EXECUTE FUNCTION public.lote_anular_trigger();


--
-- Name: lote trigg_lote_insert; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigg_lote_insert AFTER INSERT ON public.lote FOR EACH ROW EXECUTE FUNCTION public.lote_insert_trigger();


--
-- Name: articulo articulo_idempresa_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.articulo
    ADD CONSTRAINT articulo_idempresa_fkey FOREIGN KEY (idempresa) REFERENCES public.empresa(idempresa);


--
-- Name: articulo articulo_idusuario_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.articulo
    ADD CONSTRAINT articulo_idusuario_fkey FOREIGN KEY (idusuario) REFERENCES public.usuario(idusuario);


--
-- Name: articulocategoria articulocategoria_idarticulo_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.articulocategoria
    ADD CONSTRAINT articulocategoria_idarticulo_fkey FOREIGN KEY (idarticulo) REFERENCES public.articulo(idarticulo);


--
-- Name: articulocategoria articulocategoria_idcategoria_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.articulocategoria
    ADD CONSTRAINT articulocategoria_idcategoria_fkey FOREIGN KEY (idcategoria) REFERENCES public.categoria(idcategoria);


--
-- Name: categoria categoria_idcategoriapadre_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categoria
    ADD CONSTRAINT categoria_idcategoriapadre_fkey FOREIGN KEY (idcategoriapadre) REFERENCES public.categoria(idcategoria);


--
-- Name: categoria categoria_idempresa_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categoria
    ADD CONSTRAINT categoria_idempresa_fkey FOREIGN KEY (idempresa) REFERENCES public.empresa(idempresa);


--
-- Name: categoria categoria_idusuario_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categoria
    ADD CONSTRAINT categoria_idusuario_fkey FOREIGN KEY (idusuario) REFERENCES public.usuario(idusuario);


--
-- Name: comprobante comprobante_idempresa_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.comprobante
    ADD CONSTRAINT comprobante_idempresa_fkey FOREIGN KEY (idempresa) REFERENCES public.empresa(idempresa);


--
-- Name: comprobante comprobante_idmoneda_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.comprobante
    ADD CONSTRAINT comprobante_idmoneda_fkey FOREIGN KEY (idmoneda) REFERENCES public.moneda(idmoneda);


--
-- Name: comprobante comprobante_idusuario_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.comprobante
    ADD CONSTRAINT comprobante_idusuario_fkey FOREIGN KEY (idusuario) REFERENCES public.usuario(idusuario);


--
-- Name: cuenta cuenta_idcuentapadre_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cuenta
    ADD CONSTRAINT cuenta_idcuentapadre_fkey FOREIGN KEY (idcuentapadre) REFERENCES public.cuenta(idcuenta);


--
-- Name: cuenta cuenta_idempresa_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cuenta
    ADD CONSTRAINT cuenta_idempresa_fkey FOREIGN KEY (idempresa) REFERENCES public.empresa(idempresa) ON DELETE CASCADE;


--
-- Name: cuenta cuenta_idusuario_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cuenta
    ADD CONSTRAINT cuenta_idusuario_fkey FOREIGN KEY (idusuario) REFERENCES public.usuario(idusuario);


--
-- Name: detalle detalle_idarticulo_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.detalle
    ADD CONSTRAINT detalle_idarticulo_fkey FOREIGN KEY (idarticulo) REFERENCES public.articulo(idarticulo);


--
-- Name: detalle detalle_idnota_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.detalle
    ADD CONSTRAINT detalle_idnota_fkey FOREIGN KEY (idnota) REFERENCES public.nota(idnota);


--
-- Name: detallecomprobante detallecomprobante_idcomprobante_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.detallecomprobante
    ADD CONSTRAINT detallecomprobante_idcomprobante_fkey FOREIGN KEY (idcomprobante) REFERENCES public.comprobante(idcomprobante);


--
-- Name: detallecomprobante detallecomprobante_idcuenta_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.detallecomprobante
    ADD CONSTRAINT detallecomprobante_idcuenta_fkey FOREIGN KEY (idcuenta) REFERENCES public.cuenta(idcuenta);


--
-- Name: detallecomprobante detallecomprobante_idusuario_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.detallecomprobante
    ADD CONSTRAINT detallecomprobante_idusuario_fkey FOREIGN KEY (idusuario) REFERENCES public.usuario(idusuario);


--
-- Name: empresa empresa_idusuario_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.empresa
    ADD CONSTRAINT empresa_idusuario_fkey FOREIGN KEY (idusuario) REFERENCES public.usuario(idusuario);


--
-- Name: empresamoneda empresamoneda_idempresa_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.empresamoneda
    ADD CONSTRAINT empresamoneda_idempresa_fkey FOREIGN KEY (idempresa) REFERENCES public.empresa(idempresa) ON DELETE CASCADE;


--
-- Name: empresamoneda empresamoneda_idmonedaalternativa_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.empresamoneda
    ADD CONSTRAINT empresamoneda_idmonedaalternativa_fkey FOREIGN KEY (idmonedaalternativa) REFERENCES public.moneda(idmoneda);


--
-- Name: empresamoneda empresamoneda_idmonedaprincipal_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.empresamoneda
    ADD CONSTRAINT empresamoneda_idmonedaprincipal_fkey FOREIGN KEY (idmonedaprincipal) REFERENCES public.moneda(idmoneda);


--
-- Name: empresamoneda empresamoneda_idusuario_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.empresamoneda
    ADD CONSTRAINT empresamoneda_idusuario_fkey FOREIGN KEY (idusuario) REFERENCES public.usuario(idusuario);


--
-- Name: gestion gestion_idempresa_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.gestion
    ADD CONSTRAINT gestion_idempresa_fkey FOREIGN KEY (idempresa) REFERENCES public.empresa(idempresa);


--
-- Name: gestion gestion_idusuario_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.gestion
    ADD CONSTRAINT gestion_idusuario_fkey FOREIGN KEY (idusuario) REFERENCES public.usuario(idusuario);


--
-- Name: integracion integracion_idempresa_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.integracion
    ADD CONSTRAINT integracion_idempresa_fkey FOREIGN KEY (idempresa) REFERENCES public.empresa(idempresa);


--
-- Name: lote lote_idarticulo_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lote
    ADD CONSTRAINT lote_idarticulo_fkey FOREIGN KEY (idarticulo) REFERENCES public.articulo(idarticulo);


--
-- Name: lote lote_idnota_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lote
    ADD CONSTRAINT lote_idnota_fkey FOREIGN KEY (idnota) REFERENCES public.nota(idnota);


--
-- Name: moneda moneda_idusuario_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.moneda
    ADD CONSTRAINT moneda_idusuario_fkey FOREIGN KEY (idusuario) REFERENCES public.usuario(idusuario);


--
-- Name: nota nota_idcomprobante_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.nota
    ADD CONSTRAINT nota_idcomprobante_fkey FOREIGN KEY (idcomprobante) REFERENCES public.comprobante(idcomprobante);


--
-- Name: nota nota_idempresa_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.nota
    ADD CONSTRAINT nota_idempresa_fkey FOREIGN KEY (idempresa) REFERENCES public.empresa(idempresa);


--
-- Name: nota nota_idusuario_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.nota
    ADD CONSTRAINT nota_idusuario_fkey FOREIGN KEY (idusuario) REFERENCES public.usuario(idusuario);


--
-- Name: periodo periodo_idgestion_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.periodo
    ADD CONSTRAINT periodo_idgestion_fkey FOREIGN KEY (idgestion) REFERENCES public.gestion(idgestion);


--
-- Name: periodo periodo_idusuario_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.periodo
    ADD CONSTRAINT periodo_idusuario_fkey FOREIGN KEY (idusuario) REFERENCES public.usuario(idusuario);


--
-- PostgreSQL database dump complete
--

